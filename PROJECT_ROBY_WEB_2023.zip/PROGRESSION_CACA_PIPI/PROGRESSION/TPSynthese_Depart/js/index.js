"use strict";
const bonhonmeCourseHeader = document.querySelectorAll('.headerPersonnage');
bonhonmeCourseHeader.forEach(element =>{
        let chiffre = 0;
        setInterval(() => {
                if ( chiffre > 4 ){
                        chiffre = 0;
                }
                element.src = `../images/Marche${chiffre}.png`;
                chiffre++;

        },50);
});


const monkey = document.querySelectorAll('.singe');
monkey.forEach(elementDeux =>{
        let animalSinge = 1;
        setInterval(() => {
                if ( animalSinge > 17 ){
                        animalSinge = 1;
                }
                elementDeux.src = `../singes/singe${animalSinge}.png`;
                animalSinge++;

        },50);
});



// Initialisations spécifiques à la page de connexion lorsque la page est chargée (ajout des listener, etc).
window.addEventListener("load",
    function () {
        // Listener déclenché lorsqu'une zone collapsible de la page a été affichée.
        $(".collapse").on("shown.bs.collapse", function (e) {

        });

        // Listener déclenché lorsqu'une fenêtre modale vient de s'afficher.
        $('#idFenetre').on('shown.bs.modal', function () {

        });

        // Listener déclenché lorsqu'une fenêtre modale vient de se refermer.
        $('#idFenetre').on('hidden.bs.modal', function () {

        });
    }
);

function fermetureInscription(){

        if ($("#inscription").hasClass("show")) {
                $("#inscription").removeClass("show");

        }
}

function fermetureAuthentification(){
        if ($("#authentifier").hasClass("show")) {
                $("#authentifier").removeClass("show");

        }

}

