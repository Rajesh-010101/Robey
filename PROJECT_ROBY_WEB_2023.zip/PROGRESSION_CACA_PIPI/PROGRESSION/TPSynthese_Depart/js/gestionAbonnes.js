"use strict";

const CLE_AUTHENTIFIE = "ABONNE_AUTHENTIFIE";
const CLE_PREFIXE_ABONNE = "ABONNE_";

/*
    Pour les tests, on crée déjà 3 abonnés (hardcoding).
    Éventuellement, les abonnés seront créés par une fonction constructeur.
*/
function initAbonnesDepart() {
    let user = null;
    if (typeof (localStorage) != "undefined") {
        // Le mot de passe non-crypté de user1 est "Ave Maria".
        user = {nom: "user1", motDePasseCrypte: "f24d1a09990934170bbeeed20ab85758", pseudonyme: "Agathe"};
        localStorage.setItem(CLE_PREFIXE_ABONNE + user.nom, JSON.stringify(user));

        // Le mot de passe non-crypté de user2 est "Banana split".
        user = {nom: "user2", motDePasseCrypte: "8656cc8ebb46e96ab90ad17008d9d870", pseudonyme: "Brenda"};
        localStorage.setItem(CLE_PREFIXE_ABONNE + user.nom, JSON.stringify(user));

        // Le mot de passe non-crypté de user3 est "Casa Loma".
        user = {nom: "user3", motDePasseCrypte: "56628af0d9a167d119068049184246b8", pseudonyme: "Celine"};
        localStorage.setItem(CLE_PREFIXE_ABONNE + user.nom, JSON.stringify(user));
    }
}
